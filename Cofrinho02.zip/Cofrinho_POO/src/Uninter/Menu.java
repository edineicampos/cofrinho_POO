package Uninter;

import java.util.Scanner;

public class Menu {
	
	private Scanner sc;
	private Cofrinho cofrinho;
	
	public Menu() {
		sc = new Scanner(System.in);
		cofrinho = new Cofrinho();
	}
	
	public void mostrarMenu() {
		System.out.println("Cofrinho");
		System.out.println("1 - Adicionar Moeda");
		System.out.println("2 - Remover Moeda");
		System.out.println("3 - Listar Moedas");
		System.out.println("4 - Calcular valor tt convertido para rel: ");
		System.out.println("0 - Encerrar");
		
		String selecao = sc.next();
		
		switch (selecao) {
			case "0":
				System.out.println("Cofrinho Encerrado");
				break;
				
			case "1":
				mostrarSubMenuAdd();
				mostrarMenu();
				break;
				
			case "3":
				cofrinho.listagemMoedas();
				mostrarMenu();
				break;
				
			case "4":
				double valorTtConvertido = cofrinho.totalConvertido();
				System.out.println("Valor convertido para real: " + valorTtConvertido);
				mostrarMenu();
				break;
				
			default:
				mostrarMenu();
				break;
		}
		
	}
	
	private void mostrarSubMenuAdd() {
		System.out.println("Escolha uma Moeda:");
		System.out.println("1 - Real:");
		System.out.println("2 - Dolar:");
		System.out.println("3 - Euro:");
		
		int guardaMoeda = sc.nextInt();
		
		System.out.println("Digite o valor:");
		String txtMoeda = sc.next();
		txtMoeda = txtMoeda.replace("," , ".");
		double valorMoeda = Double.valueOf(txtMoeda);
		
		Moeda moeda = null;
		
		if (guardaMoeda == 1) {
			 moeda = new Real(valorMoeda);
			cofrinho.adicionar(moeda);
			
		}else if (guardaMoeda ==2) {
			 moeda = new Dolar(valorMoeda);
			cofrinho.adicionar(moeda);
		
			
		}else if (guardaMoeda ==3) {
			 moeda = new Euro(valorMoeda);
			cofrinho.adicionar(moeda);
		}else {
			System.out.println("Opção Inválida!");
			mostrarMenu();
		}
		
		
	}
}
