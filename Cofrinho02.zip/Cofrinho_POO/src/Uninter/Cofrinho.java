package Uninter;

import java.util.ArrayList;

public class Cofrinho {
	
	private ArrayList<Moeda> arrayMoedas;
	
	public Cofrinho() {
		this.arrayMoedas = new ArrayList<>();
	}
	
	public void adicionar(Moeda moeda) {
		this.arrayMoedas.add(moeda);
		
	}
	
	public void listagemMoedas() {
		if (this.arrayMoedas.isEmpty()) {
			System.out.println("Moeda não existe");
			return;
		}
		for (Moeda moeda: this.arrayMoedas) {
			moeda.info();
		}
	}

	public double totalConvertido() {
		if (this.arrayMoedas.isEmpty()) {
			return 0;
		}
		
		double acumulado = 0;
		
		for (Moeda moeda: this.arrayMoedas) {
			acumulado = acumulado + moeda.converter();
		}
		
		return acumulado;
	
	}
}
