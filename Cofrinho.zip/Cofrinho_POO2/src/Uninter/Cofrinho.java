package Uninter;

import java.util.ArrayList;

public class Cofrinho {
	
	private ArrayList<Moeda> arrayMoedas;
	
	// Construtor da classe Cofrinho
	public Cofrinho() {
		this.arrayMoedas = new ArrayList<>();
	}
	
	// Método de adição de uma moeda ao cofrinho
	public void adicionar(Moeda moeda) {
		this.arrayMoedas.add(moeda);
		
	}
	
	// Método para remover uma moeda ao cofrinho
	public void remover(Moeda moeda) {
		this.arrayMoedas.remove(moeda);
		
	}
	
	// Método para listar moedas do cofrinho
	public void listagemMoedas() {
		if (this.arrayMoedas.isEmpty()) {
			System.out.println("Moeda não existe");
			return;
		}
		for (Moeda moeda: this.arrayMoedas) {
			moeda.info();
		}
	}
	
	 // Método de calculo do valor total convertido para real
	public double totalConvertido() {
		if (this.arrayMoedas.isEmpty()) {
			return 0;
		}
		
		double acumulado = 0;
		
		for (Moeda moeda: this.arrayMoedas) {
			acumulado = acumulado + moeda.converter();
		}
		
		return acumulado;
	
	}

	
}
