package Uninter;

public class Euro extends Moeda{
	 // Construtor classe Euro onde extends Moeda
	// Os mesmos comentários valem para demais moedas: Real e Dolar
	
	public Euro(double valor) {
		this.valor = valor;
	}
	
	// Método exibe informações do o Euro
	@Override
	public void info() {
		System.out.println("Euro - " + valor);
	}
	
	// Método exibe conversão do Euro
	@Override
	public double converter() {
		return this.valor * 6; // Calculo para conversão
	}
	
	// Método de verificação caso haja dois objetos Euro =
	@Override
	public boolean equals(Object objeto) {
		if(this.getClass()!= objeto.getClass()) {
			return false;
		}
		
		Euro objetoReal = (Euro) objeto;
		
		if(this.valor != objetoReal.valor) {
			return false;
		}
		return true;
	}


}
