package Uninter;

import java.util.ArrayList;

public class Main {
	
	public static void main(String[]args) {	
	// Criar uma instância da classe Menu
	Menu menu = new Menu();
	
	// Chamar o método mostrarMenu()
	menu.mostrarMenu();
		
		
		}
}


// EDINEI CARMO DE CAMPOS FILHO - 4495860