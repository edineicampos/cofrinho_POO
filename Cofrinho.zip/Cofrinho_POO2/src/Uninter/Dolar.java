package Uninter;

public class Dolar extends Moeda {
	
	public Dolar(double valor) {
		this.valor = valor;
	}

	@Override
	public void info() {
		System.out.println("Dolar - " + valor);
	}

	@Override
	public double converter() {
		return this.valor * 5;
	}
	
	@Override
	public boolean equals(Object objeto) {
		if(this.getClass()!= objeto.getClass()) {
			return false;
		}
		
		Dolar objetoReal = (Dolar) objeto;
		
		if(this.valor != objetoReal.valor) {
			return false;
		}
		return true;
	}


}
