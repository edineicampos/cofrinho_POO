package Uninter;

import java.util.Scanner;

public class Menu {
	
	private Scanner sc;
	
	public Menu() {
		sc = new Scanner(System.in);
	}
	
	public void mostrarMenu() {
		System.out.println("Cofrinho");
		System.out.println("1 - Adicionar Moeda");
		System.out.println("2 - Remover Moeda");
		System.out.println("3 - Listar Moedas");
		System.out.println("4 - Calcular valor tt convertido para rel: ");
		System.out.println("0 - Encerrar");
		
		String selecao = sc.next();
		
		switch (selecao) {
			case "0":
				System.out.println("Cofrinho Encerrado");
				break;
		}
		
	}
}
