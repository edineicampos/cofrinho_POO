package Uninter;

import java.util.ArrayList;

public class Cofrinho {
	
	private ArrayList<Moeda> arrayMoedas;
	
	public Cofrinho() {
		this.arrayMoedas = new ArrayList<>();
	}
	
	public void adicioar(Moeda moeda) {
		this.arrayMoedas.add(moeda);
		
	}
	
	public void listagemMoedas() {
		for (Moeda moeda: this.arrayMoedas) {
			moeda.info();
		}
		
	}
	

}
