package Uninter;

import java.util.ArrayList;

public class Main {
	
	public static void main(String[]args) {	
		
//		Menu menu = new Menu();
	//	menu.mostrarMenu();
		
		Real moedaReal = new Real(1);
		moedaReal.info();
		System.out.println(moedaReal.converter());
		
		Dolar moedaDolar = new Dolar(5);
		moedaDolar.info();
		System.out.println(moedaDolar.converter());
		
		Euro moedaEuro = new Euro(5);
		moedaEuro.info();
		System.out.println(moedaEuro.converter());
		
		
		ArrayList<Moeda> arrayMoedas = new ArrayList<>();
		System.out.println("Array de Moedas: " + arrayMoedas.toString());
		
		arrayMoedas.add(moedaReal);
		arrayMoedas.add(moedaDolar);
		arrayMoedas.add(moedaEuro);
		
		for (Moeda moeda: arrayMoedas) {
			moeda.info();
			}
		}
}
